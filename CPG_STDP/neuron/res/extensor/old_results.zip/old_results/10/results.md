### Average value

![r](https://github.com/research-team/memristive-spinal-cord/blob/master/reflex_arc/neuron/new_second_layer/res/10/extra_avg.png)

### Comparing values

![r](https://github.com/research-team/memristive-spinal-cord/blob/master/reflex_arc/neuron/new_second_layer/res/10/extra_all.png)

### All results

![r](https://github.com/research-team/memristive-spinal-cord/blob/master/reflex_arc/neuron/new_second_layer/res/10/extra_v0.png)

![r](https://github.com/research-team/memristive-spinal-cord/blob/master/reflex_arc/neuron/new_second_layer/res/10/extra_v1.png)

![r](https://github.com/research-team/memristive-spinal-cord/blob/master/reflex_arc/neuron/new_second_layer/res/10/extra_v2.png)

![r](https://github.com/research-team/memristive-spinal-cord/blob/master/reflex_arc/neuron/new_second_layer/res/10/extra_v3.png)

![r](https://github.com/research-team/memristive-spinal-cord/blob/master/reflex_arc/neuron/new_second_layer/res/10/extra_v4.png)

![r](https://github.com/research-team/memristive-spinal-cord/blob/master/reflex_arc/neuron/new_second_layer/res/10/extra_v5.png)

![r](https://github.com/research-team/memristive-spinal-cord/blob/master/reflex_arc/neuron/new_second_layer/res/10/extra_v6.png)

![r](https://github.com/research-team/memristive-spinal-cord/blob/master/reflex_arc/neuron/new_second_layer/res/10/extra_v7.png)

![r](https://github.com/research-team/memristive-spinal-cord/blob/master/reflex_arc/neuron/new_second_layer/res/10/extra_v8.png)

![r](https://github.com/research-team/memristive-spinal-cord/blob/master/reflex_arc/neuron/new_second_layer/res/10/extra_v9.png)
